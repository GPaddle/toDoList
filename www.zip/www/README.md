# OnsenUI-Todo-App
Onsen UI 2.0 example To-Do app implemented in Vanilla JavaScript.

Try it here: http://frandiox.github.io/OnsenUI-Todo-App

Tutorial: https://onsen.io/blog/auto-style-app-onsen/
